﻿using Beer_API.Models;
using Microsoft.EntityFrameworkCore;

namespace Beer_API.Data
{
    public class BeersContext : DbContext
    {
        public BeersContext(DbContextOptions<BeersContext> options) : base(options)
        {

        }

        public DbSet<Beer> Beers { get; set; }
    }
}
