﻿const uri = 'api/Beers';
let allBeers = [];

function getAllBeers() {
    fetch(uri)
        .then(response => response.json())
        .then(data => displayBeers(data))
        .catch(error => console.error('Unable to get all beers.', error));
}

function displayBeers(data) {
    const body = document.getElementById('allBeers');
    body.innerHTML = '';

    data.forEach(beer => {
        let tr = body.insertRow();

        let td1 = tr.insertCell(0);
        let idNode = document.createTextNode(beer.id);
        td1.appendChild(idNode);

        let td2 = tr.insertCell(1);
        let nameNode = document.createTextNode(beer.name);
        td2.appendChild(nameNode);

        let td3 = tr.insertCell(2);
        let typeNode = document.createTextNode(beer.type);
        td3.appendChild(typeNode);

        let td4 = tr.insertCell(3);
        let ratingNode = document.createTextNode(beer.rating);
        td4.appendChild(ratingNode);
    })

    allBeers = data;
}

function addBeer() {
    const nameTextbox = document.getElementById('name');
    const typeTextbox = document.getElementById('beerType');
    const ratingTextbox = document.getElementById('rating');

    const beer = {
        name: nameTextbox.value.trim(),
        type: typeTextbox.value.trim(),
        rating: parseFloat(ratingTextbox.value.trim())
    };

    fetch(uri, {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(beer)
    })
        .then(response => response.json())
        .then(() => {
            getAllBeers();
            nameTextbox.value = '';
            typeTextbox.value = '';
            ratingTextbox.value = '';
        })
        .catch(error => console.error('Unable to add new beer.', error));
}

function updateBeer() {
    const itemId = document.getElementById('tbId').value.trim();
    let url = uri + '/' + itemId;

    const beer = findById(allBeers, itemId);
    var updateRating = document.getElementById('tbRating').value.trim();
    if (beer != null || beer != undefined) {
        beer.rating = parseFloat(updateRating);
    }

    fetch(url, {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(beer)
    })
        .then(() => getAllBeers())
        .catch(error => console.error('Unable to update beer.', error));
}

function searchBeer() {
    const searchText = document.getElementById('searchTextbox');
    let uri = 'api/Search/' + searchText.value.trim();

    fetch(uri)
        .then(response => response.json())
        .then(() => {
            getSearchBeers(uri);
        })
        .catch(error => console.error('Searching beer error.', error));
}

function getSearchBeers(uri) {
    fetch(uri)
        .then(response => response.json())
        .then(data => displayBeers(data))
        .catch(error => console.error('Unable to get search beers.', error));
}

function findById(data, id) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].id == id) {
            return data[i];
        }
    }
}

function CheckAge() {
    if (!confirm("Are you 18 years old?")) {
        alert("Drink your cup of milk and go to bed, kid!");
        this.close();
    }
}