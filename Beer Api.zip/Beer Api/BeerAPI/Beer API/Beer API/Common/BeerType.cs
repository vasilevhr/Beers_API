﻿namespace Beer_API.Common
{
    public enum BeerType
    {
        PaleAle,
        Stout,
        Lager,
        Weiss,
        IPA,
        Pilsner,
        Porter
    }
}
