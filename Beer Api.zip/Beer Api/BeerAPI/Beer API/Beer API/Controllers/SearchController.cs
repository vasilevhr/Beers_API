﻿using Beer_API.Data;
using Beer_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Beer_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController : ControllerBase
    {
        private readonly BeersContext _context;

        public SearchController(BeersContext context)
        {
            _context = context;
        }

        [HttpGet("{name}")]
        public async Task<ActionResult<IEnumerable<Beer>>> Search(string name)
        {
            var data = await (from b in _context.Beers
                              .Where(x => x.Name.ToLower().Contains(name.ToLower()))
                              select new Beer
                              {
                                  Id = b.Id,
                                  Name = b.Name,
                                  Type = b.Type,
                                  Rating = b.Rating
                              })
                               .ToListAsync();

            if (data == null)
            {
                return NotFound();
            }

            return data;
        }
    }
}
