﻿using Beer_API.Data;
using Beer_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Beer_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BeersController : ControllerBase
    {
        private readonly BeersContext _context;

        public BeersController(BeersContext context)
        {
            _context = context;
        }

        // GET: api/Beers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Beer>>> GetBeers()
        {
            return await _context.Beers.ToListAsync();
        }

        // GET: api/Beers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Beer>> GetBeer(int id)
        {
            var beer = await _context.Beers.FindAsync(id);

            if (beer == null)
            {
                return NotFound();
            }

            return beer;
        }

        // POST: api/Beers
        [HttpPost]
        public async Task<ActionResult<Beer>> PostBeer(Beer beer)
        {
            _context.Beers.Add(beer);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetBeer), new { id = beer.Id }, beer);
        }

        // PUT: api/Beer/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBeer(long id, [FromBody] Beer beer)
        {
            if (id != beer.Id)
            {
                return BadRequest();
            }

            var currBeer = _context.Beers.Where(x => x.Id == id).FirstOrDefault();
            beer.Rating = CalculateAverageRating(beer.Rating, currBeer.Rating);

            _context.Entry(beer).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BeerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private bool BeerExists(long id)
        {
            return _context.Beers.Any(e => e.Id == id);
        }

        private double CalculateAverageRating(double currRating, double newRating)
        {
            double res = (currRating + newRating) / 2;
            return res;
        }
    }
}
