﻿using Beer_API.Common;
using System.ComponentModel.DataAnnotations;

namespace Beer_API.Models
{
    public class Beer
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Beer name is mandatory field.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Beer type is mandatory field.")]
        //[Range(0,6, ErrorMessage = "Beer type must be between 0 and 6!")]
        public string Type { get; set; }

        [Range(1,5, ErrorMessage = "Rating must be between 1 and 5!")]
        public double Rating { get; set; }
    }
}
